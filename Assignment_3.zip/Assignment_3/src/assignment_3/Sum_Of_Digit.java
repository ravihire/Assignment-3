/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment_3;

import java.util.Scanner;

/**
 *
 * @author ravindra6
 */
public class Sum_Of_Digit {
    
    public static int sumDigits(int n,int sum)
    {
        if(n==0)
            return sum;
        else
        {
            sum= sum + n %10;
            n=n/10;
            return sumDigits(n,sum);
        }
        
    }
    
    public static void main(String[] args) {
    
          Scanner s=new Scanner(System.in);
          System.err.println("Enter the Number:=");
          int n=s.nextInt();
          int add=0;
         
          System.err.println("Sum of:="+sumDigits(n,add));
    }
    
}
