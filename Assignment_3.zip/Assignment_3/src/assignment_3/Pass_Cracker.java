package assignment_3;

import java.util.Random;
import java.util.Scanner;


public class Pass_Cracker {
   
    public static void main(String[] args) {
        
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the String:=");
        String str,res;
        str=sc.nextLine();
        int len=str.length(),count=0;
        Password_Generator pg=new Password_Generator();
        
        do
        {
            res=pg.generateRandomString(len);
            count++;
        }while(!str.equals(res));
        System.out.println("COUNT:= "+count);
    }
}
class Password_Generator
{
    public static final String UPPER="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    public static final String LOWER=UPPER.toLowerCase();
    public static final String SPECIAL="!@#$%^&*_+";
    public static final String NUMERIC="0123456789";
    
    int main_length=(UPPER+LOWER+NUMERIC+SPECIAL).length();
    String main_string=(UPPER+LOWER+NUMERIC+SPECIAL);
    StringBuffer sb;
    Random random;
    public String generateRandomString(int len)
    {
        sb=new StringBuffer();
        random=new Random();
        for (int i = 0; i <len; i++) {
            
            int number=random.nextInt(main_length);
            char ch=main_string.charAt(number);
            sb.append(ch);
           
        }
        return sb.toString();
        
    }
}