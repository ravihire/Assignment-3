/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment_3;

public class Execise_3 {
    static int len=0,len1=0;
    static int con=2;
    static char ch;
    static String ans="";
    private static String addCommasToNumericString(String digits)
    {
        len=digits.length();
        System.out.println("len:="+len);
        len1=len-1;
        System.out.println("len:="+len1);
        for (int i = 0; i < len; i++) {
            ch=digits.charAt(len1);
            if(con==i)
            {
                ans=ans+ch+',';
                con=con+3;
            }   
            else
            {
                   ans=ans+ch;
            }
            len1--;
        }
         return ans; 
    }
    public static void main(String[] args) {
        
        String digits="100000000";
        char ch;
        String res=addCommasToNumericString(digits);
        for(int i=res.length()-1;i>=0;i--)
        {
            ch=res.charAt(i);
            System.out.print(ch);
        }
        
    }
    
}
