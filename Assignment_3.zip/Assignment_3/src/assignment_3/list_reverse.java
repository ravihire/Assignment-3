/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment_3;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
public class list_reverse {
    
    public static void main(String[] args) {
        
        List<Integer> list=new ArrayList<>();
        list.add(10);
        list.add(20);
        list.add(30);
        list.add(40);
        list.add(50);
        
        ListIterator<Integer> litr=list.listIterator();
        
        System.out.println("Traversing Elements in Reverse Direction...");
        while(litr.hasPrevious())
        {
            System.out.println("Element Of:="+litr.previous());
        }
    }
    
}
