/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment_3;

/**
 *
 * @author ravindra6
 */
public class Execise_2 {
    public static void main(String[] args) {
        String str="bookkeeper";
        int len=str.length();
        int i,j,c=0;
        char[] ch=str.toCharArray();
        char[] ch2=new char[len];
        for (i = 1; i <=len; i++) {
            
            for(j=1;j<=len;j++)
            {
                if(str.charAt(ch[i])==str.charAt(ch[j]))
                {
                    c++;    
                }
            }
            if(c==1)
            {
                ch2[i]=ch[j];
            }
            else
            {
                ch2[i]=ch[j];
            }
        }
        for(i=0;i<ch2.length;i++)
        {
              System.out.println("ch2["+ch2[i]+"]");
        }
    }
}
