/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment_3;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;


public class Execise_4 {
    
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        HashMap<Integer,String> map=new HashMap<>();
        int i=1,c=0;
        System.out.println("Enter the String:=");
        String str="";
        while(!(str=s.nextLine()).equals(""))
        {
            map.put(i, str);
            i++;
        }
        for (Map.Entry<Integer, String> entry : map.entrySet()) {
            Integer key = entry.getKey();
            String value = entry.getValue();
            if(map.containsValue(value))
            {
                c++;
            }
            else
            {
                System.out.println("Map:="+key+" "+value);
            }
        }
        System.out.println("C:= "+c);
    } 
    
} 
