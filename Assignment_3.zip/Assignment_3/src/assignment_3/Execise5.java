package assignment_3;


import java.util.Scanner;

public class Execise5 {

	public static void main(String[] args) 
{
	
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a First Number:=");
		int first_number=sc.nextInt();
		System.out.println("Enter a Second Number:=");
		int second_number=sc.nextInt();
		int sub=0,temp=0;
                
                sub=first_number-second_number;
                
                if(first_number<0 || second_number<0)
                {
                    System.err.println("Substraction is not Possible");
                }
                else if(sub<0)
                {
                    System.err.println("One Possible Substraction Possible:=");
                    System.err.println(first_number+" - "+second_number+" = "+sub);
                }
                else
                {
                    System.err.println(first_number+" - "+second_number+" = "+sub);
                }
		while(sub>0)
		{
			temp=sub;
			temp=temp-first_number;
			System.out.println(Math.abs(temp)+" - "+first_number+" = "+temp);
			sub=temp;
		}
		
	}

}