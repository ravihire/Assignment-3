/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment_3;

/**
 *
 * @author ravindra6
 */
public class Execise_2_main {
    
    public static void main(String[] args)
    {
        String str="bookkeeper";
        int len=str.length();
        String out="";
        char ch;
        for (int i = 0; i < len; i++)
        {
            ch=str.charAt(i);
            if(ch!=' ')
            {
                out=out+ch;
            }
            str=str.replace(ch, ' ');       
        }  
        System.out.println("Output:="+out);
    }
    
}
//while(!(line=scanner.nextLine()).equals("")) {
           // names.add(line);