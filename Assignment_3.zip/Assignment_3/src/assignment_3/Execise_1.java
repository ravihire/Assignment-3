/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment_3;

import java.util.HashMap;
import java.util.Map;

public class Execise_1 {

    public static void main(String[] args) {
       
        HashMap<String,String> hashmap1=new HashMap<>();
        HashMap<String,String> hashmap2=new HashMap<>();
        
        hashmap1.put("Ravi", "Hire");
        hashmap1.put("Raj", "Tande");
        hashmap1.put("Naresh", "Kadhare");
        hashmap1.put("Navneet", "Pagdhal");
        hashmap1.put("Venus", "kumbhaniya");
        hashmap1.put("Bhaveshhhh", "Jadav");
        
        hashmap2.put("Ravi", "Hire");
        hashmap2.put("Sandip", "Chitrakathe");
        hashmap2.put("Sagar", "Hire");
        hashmap2.put("Arjun", "Jagtap");
        hashmap2.put("Naresh", "Kadhare");
        hashmap2.put("Venus", "kumbhaniya");
        
       
        Check check=new Check();        
        int count=check.commonKeyValuePairs(hashmap1, hashmap2);
        System.out.println("Common Pairs:="+count);
    }
    
}
class Check
{
        int count=0;
        public int commonKeyValuePairs(HashMap<String,String> map1,HashMap<String,String> map2)
        {
            for (Map.Entry<String, String> entry : map1.entrySet())
            {
                String key = entry.getKey();
                String value = entry.getValue();
                for (Map.Entry<String, String> entry1 : map2.entrySet())
                {
                    String key1 = entry1.getKey();
                    String value1 = entry1.getValue();
                    if((key.equalsIgnoreCase(key1)) && (value.equalsIgnoreCase(value1)))
                    {
                        count++;
                    }    
                }
            }
           return count;
        }
}
